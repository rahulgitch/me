## Description

[Add feature/bug description here]

## How to reproduce

[Add steps on how to reproduce this issue]

## What do you expect

[Describe what do you expect to happen]

## What happened instead

[Describe the actual results]

## Software:

- Rails version: [Add rails version here]
- Browser gem version: [Add browser gem version here]

## Full backtrace

```text
[Paste full backtrace here]
```

## Report

[Visit <https://user-agent.herokuapp.com> and paste the URL here]
