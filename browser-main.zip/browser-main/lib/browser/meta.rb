# frozen_string_literal: true

require_relative "meta/base"
require_relative "meta/generic_browser"
require_relative "meta/id"
require_relative "meta/ie"
require_relative "meta/ios"
require_relative "meta/mobile"
require_relative "meta/platform"
require_relative "meta/proxy"
require_relative "meta/safari"
require_relative "meta/webkit"
require_relative "meta/tablet"
require_relative "meta/device"
