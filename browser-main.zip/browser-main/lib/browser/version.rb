# frozen_string_literal: true

module Browser
  VERSION = "6.2.0"
end
