# frozen_string_literal: true

require_relative "browser/browser"
require_relative "browser/rails" if defined?(Rails)
